import React, { useEffect, useState } from "react";

function TodoList() {
  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch data from API
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/todos")
      .then((response) => response.json())
      .then((data) => {
        setTodos(data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <h2 className="text-center text-blue-500 mt-5">Loading...</h2>;
  }

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>📋 Todo List</h2>
      <ul style={styles.list}>
        {todos.slice(0, 10).map((todo) => (
          <li
            key={todo.id}
            style={{
              ...styles.item,
              backgroundColor: todo.completed ? "#d1ffd6" : "#ffe4e1",
            }}
          >
            <strong>{todo.title}</strong>
            <span style={styles.status}>
              {todo.completed ? "✅ Done" : "❌ Pending"}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: "600px",
    margin: "50px auto",
    padding: "20px",
    borderRadius: "10px",
    backgroundColor: "#f9f9f9",
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
  },
  heading: {
    textAlign: "center",
    color: "#333",
    marginBottom: "20px",
  },
  list: {
    listStyle: "none",
    padding: 0,
  },
  item: {
    marginBottom: "10px",
    padding: "10px",
    borderRadius: "8px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  status: {
    fontWeight: "bold",
  },
};

export default TodoList;