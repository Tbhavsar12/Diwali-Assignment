package com.demo.tree;

public class BSTNode {
	 int data;
	    BSTNode left, right;

	    public BSTNode(int data) {
	        this.data = data;
	        this.left = null;
	        this.right = null;
	    }

}
